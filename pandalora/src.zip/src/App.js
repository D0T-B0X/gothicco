import React from "react";
import GLBViewer from "./components/glbviewer";

export default function App() {
  return (
    <div className="w-screen min-h-screen bg-[#0d0d0d] text-white flex flex-col items-center justify-center p-4 space-y-6">
      
      
      <h1 className="text-3xl font-bold text-center">
        Welcome to Bambinopanda 🐼
      </h1>

     
      <div className="w-[240px] h-[240px] md:w-[300px] md:h-[300px] rounded-full overflow-hidden shadow-xl border border-white/10">
        <GLBViewer />
      </div>

    </div>
  );
}
